# JZ Wall Art & Digitals

A premium, fully static e-commerce front-end for selling digital Google Sheets
templates — built with HTML, Tailwind CSS (CDN), vanilla JavaScript, and a
custom design system in `css/style.css`. No build step required.

## What's included

```
index.html        Home
shop.html          Shop (search, category + price filters, sort, wishlist)
product.html       Product detail (?id=<slug>) — gallery, tabs, reviews, FAQ
about.html         Brand story
contact.html       Contact form
faq.html           Grouped FAQ with schema markup
privacy.html       Privacy Policy
terms.html         Terms & Conditions
admin.html         Front-end admin dashboard demo (see "Admin" below)
css/style.css      Design tokens, components, animations
js/products-data.js  Single source of truth for all 11 products
js/main.js         Cart/buy modal, wishlist, dark mode, search, toasts, SVG thumbnails
js/partials.js      Shared nav + footer, injected into every page
sitemap.xml, robots.txt   SEO
```

## Design system

- Colors, typography and the "live cell" signature motif (spreadsheet cell
  references like `A1`, `B2` used as section eyebrows, plus an animated gold
  selection box in the hero) are defined once in `css/style.css` as CSS
  variables, so re-theming only touches one file.
- Dark mode is a `class="dark"` toggle on `<html>`, persisted to `localStorage`.
- Product thumbnails are generated on the fly as SVG "spreadsheet grids"
  (`cellThumbSVG()` in `js/main.js`) — this keeps the whole store dependency
  and licensing-free. Swap in real screenshots by adding an `images` array to
  a product in `js/products-data.js` and updating the gallery markup in
  `product.html`.

## Running locally

No build tools needed. From this folder:

```bash
python3 -m http.server 8080
# then open http://localhost:8080
```

## Deploying

**GitHub Pages** — push this folder to a repo, enable Pages on the `main`
branch (root), done.

**Netlify / Cloudflare Pages** — drag-and-drop this folder in the dashboard,
or connect the repo with build command `none` and publish directory `/`.

Before going live, update:
- Every `https://www.jzwallart.com/...` URL in the `<head>` tags, `sitemap.xml`
  and `robots.txt` to your real domain.
- `assets/og-cover.jpg` — add a real 1200×630 Open Graph image and reference it.

## Connecting real payments (Stripe / Razorpay / Gumroad)

This is a static front-end, so checkout is currently a UI simulation
(`openBuyModal`, `confirmPurchase` in `js/main.js`). To go live you need a
small backend (a few serverless functions are enough):

1. **Stripe** — create a Checkout Session server-side
   (`stripe.checkout.sessions.create`) with the product price and a
   `success_url`; redirect the browser there. On the `checkout.session.completed`
   webhook, email the buyer their download link.
2. **Razorpay** — create an Order server-side (`razorpay.orders.create`),
   open Razorpay Checkout client-side with the order ID, verify the payment
   signature server-side, then email the download link.
3. **Gumroad** — simplest option: skip your own checkout entirely and deep-link
   `confirmPurchase()` to `https://yourstore.gumroad.com/l/<product-slug>`;
   Gumroad handles payment and instant delivery for you.

Replace the `setTimeout` block inside `confirmPurchase()` in `js/main.js` with
real `fetch()` calls to your endpoints once they exist — the comment in that
function shows exactly where.

## Admin dashboard

`admin.html` is a working demo: product CRUD, price/link editing, an order
table and a customer table all persist to `localStorage` so you can click
through the whole flow. It is **not connected to a real database** — for
production, point it at your backend (e.g. a small Node/Express or serverless
API backed by Postgres/Firebase) and swap the `Store.get/set` calls for
`fetch()` calls to that API. The page is excluded from search indexing via
`robots.txt` and a `noindex` meta tag; add real authentication before
deploying it publicly.

## SEO

- Per-page `<title>`, meta description, canonical, Open Graph and Twitter Card
  tags.
- JSON-LD schema: `Organization` + `WebSite` (home), `Product` with
  `AggregateRating`/`Offer` (product pages), `FAQPage` (FAQ page).
- `sitemap.xml` and `robots.txt` included at the project root.
- Semantic headings, `aria-label`s on icon buttons, visible focus states, and
  `prefers-reduced-motion` support throughout.

## Notes

- Tailwind is loaded via the CDN script for a zero-build workflow. For a
  production optimization pass, migrate to the Tailwind CLI/PostCSS build so
  only used classes ship (smaller CSS, no runtime compile).
- Coupon codes for the demo checkout: `JZ15`, `WELCOME10`, `BUNDLE20`.
